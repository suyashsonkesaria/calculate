# Package Calculate

Calculates addition, subtraction, multiplication and division.

